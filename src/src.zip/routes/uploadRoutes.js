//src/routes/uploadRoutes.js
