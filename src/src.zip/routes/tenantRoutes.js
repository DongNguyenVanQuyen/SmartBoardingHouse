//src/routes/tenantRoutes.js
